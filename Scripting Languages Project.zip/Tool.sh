#!/bin/bash
Hashing() {
SHA256(){
sleep 1
HashData="HashDataBaseSHA256"
read -p "Enter file: " file

if [ ! -f "$file" ]; then
    echo "No file"
    exit 1
fi

SavedHash=$(grep " $file$" "$HashData" 2>/dev/null | awk '{print $1}')

if [ -z "$SavedHash" ];then
    sha256sum "$file" >> "$HashData"
    echo "Hash saved"
else 

	Current=$(sha256sum "$file" | awk '{ print $1 }')  
	 if [ "$Current" = "$SavedHash" ];then
		echo "The $file file is safe there is no changes "
	else
		echo "Warning ! ! ! ! !"
		sleep 1
		echo "The $file file Has been changed"
	fi
fi  
}

MD5(){
sleep 1
HashMD5="HashDataBaseMD5"
read -p "Enter your file " File2
if [ ! -f "$File2" ] ;then
	echo "File not found"
	exit 1
fi	
SavedMD5=$(grep "$File2$" "$HashMD5" 2>/dev/null | awk '{print $1 }' ) 
if [ -z "$SavedMD5" ]; then
	md5sum "$File2" >> $HashMD5
	echo "Hash saved"
else
	CurrentMD5=$(md5sum "$File2" | awk '{print $1}')
	if [ "$CurrentMD5" = "$SavedMD5" ] ; then
		echo "The $File2 file is safe "
	else
		echo "Warning ! ! ! ! !"
		sleep 1
		echo " The $File2 file has been changed"
		fi
fi
}		

while true; do
echo
echo "=== Choose The hashing ALgorithm ==="
echo "1) SHA256"
echo "2) MD5"
echo "3) Exit"
read -p "Choose: " choice
case "$choice" in
1) SHA256 ;;
2) MD5 ;;
3) exit 0 ;;
*) echo "Invalid choice." ;;
esac
done

}

FilePermissionsChecker() {
echo "=========================================================File Permissions Checker ================================================"

read -p "Enter File " file
if [ ! -f "$file" ] ;then
	echo "File not Exists "
	exit 1
fi
ls -la "$file" | awk '{ print $1 }'
Permission=$(ls -la "$file" | awk '{ print $1 }')
if [[ "$Permission" = *"-rwxrwxrwx"* ]]; then
	echo "Warning ! ! ! ! this file has full permissions "
	sleep 2
	chmod 544 $file
	echo "$file" " Permissions has been changed the file is safe now " 
	ls -la "$file" | awk '{ print $1 }'
elif [[ "$Permission" = *"-rwx-wx-wx"* ]]; then
	echo "Warning The Group and others have write and execute permissions "
	sleep 2	
	chmod 544 $file
	echo "File is safe now"
	ls -la "$file" | awk '{ print $1 }'
elif [[ "$Permission" = *"-rwx--x--x"* ]]; then	
	echo " Warning Others and groups have Write permission "
	sleep 2	
	chmod 544 $file
	echo "File is safe now"
	ls -la "$file" | awk '{ print $1 }'
elif [[ "$Permission" = *"-rwxrwx---"* || "$Permission" = *"-rwxrwxr--"* || "$Permission" = *"-rwxrwxr-x"* ]];then	
	echo " Warning groups have full permission "
	sleep 2	
	chmod 544 $file
	echo "File is safe now"
	ls -la "$file" | awk '{ print $1 }'		
elif [[ "$Permission" = *"-rwx---rwx"* || "$Permission" = *"-rwxr-xrwx"* ]]; then	
	echo " Warning Others have full permission "
	sleep 2	
	chmod 544 $file
	echo "File is safe now"
	ls -la "$file" | awk '{ print $1 }'
else
	echo "File is safe"
fi

}

PassCheck() {
read -p "Enter your Password " Password
s=0
if [[ "$Password" =~ [A-Z] ]] 
then
#echo " You Have Bigger case "
((s+=50))
#else 
#echo " You need to use Bigger case to make it more Secure "
fi
if [ ${#Password} -gt 8 ]
then
#echo "the lentgh of your password is good"
((s+=100))
#else 
#echo "You need to make your password length more than 8 to make it more Secure"
fi
if [[ "$Password" =~ [a-z] ]]
then 
#echo "You have lower case "
((s+=50))
#else 
#echo "You need to add lower case make it more Secure"
fi
if [[ "$Password" =~ [0-9] ]]
then 
#echo "You Have Numbers" 
((s+=50))
#else 
#echo "You need to to add numbers to make it more Secure"
fi
if [[ "$Password" =~ [!-*] ]]
then
#echo "You Have symbols "
((s+=100))
#else 
#echo "You need to add symbols to make it Secure"
fi
echo "$s"
if [ $s -gt 300 ] 
then
echo " Your Password Is great "
elif [ $s -ge 250 ] 
then
echo  "Your Password Is good "
else
echo "Your password is weak ! try to make it better "
fi


}

Encryption(){
echo "=========================================== Encryption ==============================================="
sleep 1
read -p "Enter the file name " file
if [ ! -f "$file" ];then
	echo "File not found "
	exit 1
else	
	read -p "Choose E for encryption or D for Decryption" CH
	if [ $CH = "E" ];then
	openssl enc -aes-256-cbc -in $file -out "$file.enc"
	rm -rf "$file"
	elif [ $CH = "D" ] ;then
		read -p "Please Enter your New name for the file " N
		sleep 1
		openssl enc -aes-256-cbc -d -in $file -out "$N"
		rm -rf "$file"
		
	else
		echo "invalid input "
	fi	
	
fi
}


echo
echo  "==================================== >>>>>>>>>>>>>>>>> Security Tool <<<<<<<<<<<<<<<<<<<<<<<<< ==========================================
===========================================Scripting Langauges Project=========================================================================="
echo "1) Check File Integrity"
echo "2) FilePermissionsChecker"
echo "3) Password Strength Checker"
echo "4) File Encryption"
echo "5) Exit"
read -p "Choose: " choice
case "$choice" in
1) Hashing ;;
2) FilePermissionsChecker ;;
3) PassCheck ;;
4) Encryption ;;
5) exit 0 ;;
*) echo "Invalid choice." ;;
esac

